import matplotlib.pyplot as plt
from db_config import get_redis_connection
import json

class WeatherDataPlotter:
    def __init__(self, redis_client):
        """
        Initializes the WeatherDataPlotter object.

        Args:
            redis_client: Redis client object to interact with Redis.
        """
        self.redis_client = redis_client
        
    def plot_relative_humidity(self):
        """
        Plots the relative humidity for each city stored in Redis.

        """
        relative_humidity_values = []
        cities = []

        for key in self.redis_client.scan_iter("weather_data:*"):
            weather_data_str = self.redis_client.execute_command('JSON.GET', key)

            if weather_data_str:
                weather_data = json.loads(weather_data_str)
                relative_humidity = float(weather_data.get('RelativeHumidity', 0))
                city = weather_data.get('City', '')

                relative_humidity_values.append(relative_humidity)
                cities.append(city)

        plt.bar(cities, relative_humidity_values, color='green')
        plt.title('Relative Humidity in Cities')
        plt.xlabel('City')
        plt.ylabel('Relative Humidity (%)')
        plt.xticks(rotation=45, ha='right')
        plt.show()

redis_client = get_redis_connection()
weather_plotter = WeatherDataPlotter(redis_client)
weather_plotter.plot_relative_humidity()
