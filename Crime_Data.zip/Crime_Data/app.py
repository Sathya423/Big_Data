import requests
from db_config import get_redis_connection
import json

class APIDataFetcher:
    """
    A class to fetch data from various APIs and store it in Redis.
    """

    def __init__(self, redis_client, api_key, api_host):
        """
        Initializes the APIDataFetcher object.

        Args:
            redis_client: Redis client object to interact with Redis.
            api_key (str): The API key to authenticate with the API.
            api_host (str): The host of the API.
        """
        self.redis_client = redis_client
        self.api_key = api_key
        self.api_host = api_host

    def fetch_data(self, url, querystring):
        """
        Fetches data from the specified API.

        Args:
            url (str): The URL of the API endpoint.
            querystring (dict): The query parameters to include in the request.

        Returns:
            dict: A dictionary containing the fetched data, or None if fetching failed.
        """
        headers = {
            "X-RapidAPI-Key": self.api_key,
            "X-RapidAPI-Host": self.api_host
        }
        response = requests.get(url, headers=headers, params=querystring)
        if response.status_code == 200:
            return response.json()
        else:
            return None

    def dump_to_redis(self, data, key):
        """
        Stores the fetched data in Redis.

        Args:
            data (dict): The data to store in Redis.
            key (str): The key under which to store the data.
        """
        if data:
            if self.redis_client.exists(key):
                self.redis_client.delete(key)
            self.redis_client.execute_command('JSON.SET', key, '.', json.dumps(data))
            print(f"Data stored in Redis successfully!")
        else:
            print("Failed to fetch data.")

redis_client = get_redis_connection()

api_key = "ea341da3eamsh8f7ddd838e045b2p1b1727jsn78e845e3b3f8"
api_host = "us-weather-by-zip-code.p.rapidapi.com"
url = "https://us-weather-by-zip-code.p.rapidapi.com/getweatherzipcode"
querystring = {"zip": ["94111", "08028", "08012", "19101", "08101"]}

for zip_code in querystring['zip']:
    query = {"zip": zip_code}
    key = 'weather_data:' + zip_code
    api_fetcher = APIDataFetcher(redis_client, api_key, api_host)
    weather_data = api_fetcher.fetch_data(url, query)
    api_fetcher.dump_to_redis(weather_data, key)
