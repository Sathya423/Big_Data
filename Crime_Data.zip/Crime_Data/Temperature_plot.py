import matplotlib.pyplot as plt
from db_config import get_redis_connection
import json

class WeatherDataPlotter:
    def __init__(self, redis_client):
        """
        Initializes the WeatherDataPlotter object.

        Args:
            redis_client: Redis client object to interact with Redis.
        """
        self.redis_client = redis_client
        
    def plot_temperature(self):
        """
        Plots the temperature for each city stored in Redis.

        """
        temperatures = []
        cities = []

        for key in self.redis_client.scan_iter("weather_data:*"):
            weather_data_str = self.redis_client.execute_command('JSON.GET', key)

            if weather_data_str:
                weather_data = json.loads(weather_data_str)
                temp_f = float(weather_data.get('TempF', 0))
                city = weather_data.get('City', '')

                temperatures.append(temp_f)
                cities.append(city)

        plt.bar(cities, temperatures, color='blue')
        plt.title('Temperature in Cities')
        plt.xlabel('City')
        plt.ylabel('Temperature (F)')
        plt.xticks(rotation=45, ha='right')
        plt.show()

redis_client = get_redis_connection()
weather_plotter = WeatherDataPlotter(redis_client)
weather_plotter.plot_temperature()
